import math

#help(math)

#floor, celi, round method
# value = 26.5
# print(math.floor(value))

# print(math.ceil(value))

# print(round(value))

from math import pi

#pi value
# pi_value = pi
# print(pi_value)

#inf
# num = -5 < math.inf
# print(num)

#log

# print(math.log(100,2))

# print(pow(2,6.643856189774725))

import random

#seed method
# random.seed("me")
# a = random.randint(0,100)
# print(a)


# random.seed(2)
# b = random.randint(1,100)
# print(b)

#choice method
my_list = [1,2,3,4,5,6,7,8,9]
print(random.choice(my_list))

