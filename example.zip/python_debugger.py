import pdb

a = [1,2,3,4]
a1 = [6,7,8,9]

b =10
print("A is: ",a)

print("B is: ",b)
res_ = a + a1
print(res_)

pdb.set_trace()
res = a + b
print(res)
